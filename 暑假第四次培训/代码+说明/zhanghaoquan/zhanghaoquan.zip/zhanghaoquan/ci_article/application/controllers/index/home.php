<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 默认前台
 */
class Home extends CI_Controller{

    /**
     * 默认首页
     */
    public function index(){
        $this->load->view('index/home');
    }

    public function introduce(){
        $this->load->view('index/introduce');
    }

    public function newContent(){
        $this->load->view('index/newcontent');
    }

    public function LeMesge(){
        $this->load->view('index/leaveMessage');
    }

    public function newslist(){
        $this->load->view('index/newslist');
    }

    public function download(){
        $this->load->view('index/download');
    }

    public function eop(){
        $this->load->view('index/eop');
    }

    public function pc(){
        $this->load->view('index/pc');
    }

    public function mh(){
        $this->load->view('index/mh');
    }
}