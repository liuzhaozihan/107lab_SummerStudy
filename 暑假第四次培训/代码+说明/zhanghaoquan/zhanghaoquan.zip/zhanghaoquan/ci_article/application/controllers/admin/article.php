<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Article extends CI_Controller{

	/**
	 * 新闻中心
	 */
	public function newslist(){
		$this->load->view('admin/newslist');
	}
	/**
	 * 心理百科
	 */
	public function eop(){
		$this->load->view('admin/eop');
	}
	/**
	 * 心理咨询
	 */
	public function pc(){
		$this->load->view('admin/pc');
	}
	/**
	 * 管理员
	 */
	public function mate(){
		$this->load->view('admin/mate');
	}
	/**
	 * 心理健康
	 */
	public function mh(){
		$this->load->view('admin/mh');
	}
	/**
	 * 轮播图管理
	 */
	public function banner(){
		$this->load->view('admin/banner');
	}
	/**
	 * 下载中心
	 */
	public function download(){
		$this->load->view('admin/download');
	}
	/**
	 * 留言查看
	 */
	public function LeMesge(){
		$this->load->view('admin/LeMesge');
	}
	/**
	 * 信息修改
	 */
	public function modify(){
		$this->load->view('admin/modify');
	}

	public function send_article(){
		$this->load->helper('form');
		$this->load->view('admin/article');
	}

	public function send(){
			$this->load->helper('form');
			$this->load->view('admin/article');
	}


	public function edit_article(){
		$this->load->helper('form');
		$this->load->view('admin/adit_article');
	}

	public function edit(){
		$this->load->library('form_validation');
		$status = $this->form_validation->run('article');

		if($status){
			echo '数据库操作';
		}else{
			$this->load->library('form_validation');
			$status = $this->form_validation->run('article');

		}
	}
}