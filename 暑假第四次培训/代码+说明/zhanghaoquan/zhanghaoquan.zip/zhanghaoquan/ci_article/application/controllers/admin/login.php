<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller{

    /**
     * 后台登陆
     */
    public function index(){
        $this->load->view('admin/login');
    }

    public function yzm(){
        $this->load->view('admin/yzm');
    }

    public function register(){
        $this->load->view('admin/register');
    }
}