<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Category extends CI_Controller{

    public function add_cate(){
        $this->load->helper('form');
		$this->load->view('admin/add_cate');
    }

    public function add(){
        $this->load->library('form_validation');
		$status=$this->form_validation->run('cate');
		
		if($status){
            $data = array(
                'cname' => $this->input->post('cname')
            );
            $this->load->model('category_model','cate');
            $this->cate->add($data);
            success('admin/category/index','添加成功');
		}else{
			$this->load->helper('form');
		    $this->load->view('admin/add_cate');
		}
    }

    public function edit_cate(){
        $this->load->helper('form');
        $this->load->view('admin/edit_cate');
    }

    public function edit(){
        $this->load->library('form_validation');
		$status=$this->form_validation->run('cate');
		
		if($status){
			echo '数据库';
		}else{
			$this->load->helper('form');
		    $this->load->view('admin/edit_cate');
		}
    }
}