<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Category extends CI_Model{
    
    public function add(){
        $this->db->insert('category',$data);
    }

    public function check(){
        $data = $this->db->get('category')->result_array();
        p($data);
    }
}