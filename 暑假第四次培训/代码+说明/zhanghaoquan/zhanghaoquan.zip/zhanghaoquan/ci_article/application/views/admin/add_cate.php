<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo base_url().'style/admin/'?>css/public.css" />
    <title>Document</title>
    <style>
        span{
            color:#f00;
        }
    </style>
</head>
<body>
    <form action="<?php echo site_url('admin/category/add')?>" method="post">
    <table class="table">
        <tr>
            <td class="th" colspan="10">添加栏目</td>
        </tr>
        <tr>
            <td>栏目名称</td>
            <td><input type="text" name="cname" value="<?php echo set_value('cname')?>">
            <?php echo form_error('cname','<span>','</span>')?></td>
        </tr>
        <tr>
            <td colspan="10"><input type="submit" value="添加" class="input_button"></td>
        </tr>
    </table>
    </form>
</body>
</html>