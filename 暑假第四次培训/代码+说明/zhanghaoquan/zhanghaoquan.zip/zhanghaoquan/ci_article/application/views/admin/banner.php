<?php
session_start();
@$admin = $_SESSION['user'];
function connectDb()
    {
        $link = mysqli_connect("localhost", "root", "123456");
        if ($link) {
            mysqli_select_db($link, 'text');
            mysqli_query($link, "SET NAMES 'utf8'");
        } else {
            echo mysqli_error($link);
        }
        return $link;
    }
    $link = connectDb();
    if(isset($_POST['submit'])){
        if (((@$_FILES["file"]["type"] == "image/gif")
            || (@$_FILES["file"]["type"] == "image/jpeg")
            || (@$_FILES["file"]["type"] == "image/pjpeg")
            || (@$_FILES["file"]["type"] == "image/png")
            || (@$_FILES["file"]["type"] == "image/jpg"))
        ) {
            if (@$_FILES["file"]["error"] > 0) {
                echo "Return Code: " . @$_FILES["file"]["error"] . "<br />";
            } else {
                $icon_tem = "images/" . @$_FILES["file"]["name"];
                $icon_arr = array("$icon_tem");
                $icon = implode($icon_arr);
                mysqli_query($link,"INSERT INTO banner(title) VALUES ('$icon')");
                echo "<script language=\"JavaScript\">alert(\"上传成功\");</script>";
                }
        }else{
            echo "<script language=\"JavaScript\">alert(\"图片格式有误\");</script>";
        }
    }
    $result_img = mysqli_query($link, "SELECT * FROM banner");
    $dataCount_2 = mysqli_num_rows($result_img);
    $show = false;
    $icon=array();
    for ($i = 0; $i < $dataCount_2; $i++) {
        $result_arr = mysqli_fetch_assoc($result_img);
        $icon[]=$result_arr['title'];
        $show = true;
    }

    if(isset($_POST['delall'])){
        mysqli_query($link,'truncate table banner');
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo base_url().'style/admin/'?>css/public.css" />
    <link rel="stylesheet" href="<?php echo base_url().'style/index/'?>css/swiper-6.0.4/package/swiper-bundle.min.css">
    <script text="text/script" src="<?php echo base_url().'style/index/'?>js/jquery-3.4.1.js"></script>
</head>
<body>
    <table class="table">
        <tr>
            <td class="th" colspan="10">主页轮播图管理</td>
        </tr>
        <tr>
            <td colspan="4">
                <div class="swiper-container swiper1">
                    <div class="swiper-wrapper">
                        <?php
                            for($i = 0; $i < $dataCount_2; $i++){?>
                            <div class='swiper-slide'>
                                <img src='<?php echo base_url().'style/index/'.$icon[$i]?>' alt='NO FOUND'>
                            </div>
                            <?php }
                        ?>
                    </div>
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>
                </div>
            </td>
        </tr>
        <form action="<?php echo site_url('admin/article/banner')?>" method="post" enctype="multipart/form-data">
        <tr>
            <td>图片上传</td>
            <td><input type="file" name="file"/></td>
            <td><input type="submit" name="submit"/></td>
            <td><input type="submit" name="delall" value="删除全部"></td>
        </tr>
        </form>
    </table>
    <script src="<?php echo base_url().'style/index/'?>css/swiper-6.0.4/package/swiper-bundle.min.js"></script>
</body>
<script>        
    var swiper = new Swiper('.swiper-container', {
        loop:true,
        spaceBetween: 30,
        effect: 'fade',
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });
</script>
</html>