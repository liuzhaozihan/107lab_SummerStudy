<?php
function news($pageNum = 1, $pageSize = 10)
    {
        $array = array();
        $link = mysqli_connect('localhost','root','123456');
        mysqli_set_charset($link,'utf8');
        mysqli_select_db($link,"text");
        $rs = "select * from newslist limit " . (($pageNum - 1) * $pageSize) . "," . $pageSize;
        $r = mysqli_query($link, $rs);
        while ($obj = mysqli_fetch_object($r)) {
            $array[] = $obj;
        }
        mysqli_close($link,"text");
        $array = array_reverse($array);
        return $array;
    }
function allNews()
    {
        $link = mysqli_connect('localhost','root','123456');
        mysqli_set_charset($link,'utf8');
        mysqli_select_db($link,"text");
        $rs = "select count(*) num from newslist";
        $r = mysqli_query($link, $rs);
        $obj = mysqli_fetch_object($r);
        mysqli_close($link,"text");
        return $obj->num;
    }
function connectDb()
    {
        $link = mysqli_connect('localhost','root','123456');
        if($link){
            mysqli_select_db($link,'text');
            mysqli_query($link,'SET NAMES UTF8');
        }else{
            echo mysqli_error($link);
        }
        return $link;
    }

    $link = connectDb();

    @$allNum = allNews();

    @$pageSize = 10;

    @$pageNum = empty($_GET["pageNum"])?1:$_GET["pageNum"];

    @$endPage = ceil($allNum/$pageSize);

    @$array = news($pageNum,$pageSize);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>newslist-计算机与信息工程学院官网</title>
    <link rel="stylesheet" href="<?php echo base_url().'style/index/'?>css/public.css">
    <link rel="stylesheet" href="<?php echo base_url().'style/index/'?>css/newslist.css">
    <script text="text/javascript" src="<?php echo base_url().'style/index/'?>js/jquery-3.4.1.js"></script>
    <script text="text/javascript" src="<?php echo base_url().'style/index/'?>js/public.js"></script>
    <script>
        $(function () {  
            $('#b1').click(function(){
	        val = $('#p').val();
	        if(!val){
	        	alert('请输入页码！');
		    }else{
		        if(val.match(/^\d+$/g)){
		    	    location='admin.php?pageNum='+val;
		    	}else{
		    	}
		    }
            })
        })
    
    </script>
</head>
<body>
    <!-- 顶部选项 -->
    <div class="Header">
        <pre>设为首页 | 加入收藏</pre>
    </div>
    <!-- Logo -->
    <div class="Logo">
       <img src="<?php echo base_url().'style/index/'?>images/ICON.png" alt="NO FOUND">
    </div>
    <!-- 菜单栏 -->
    <div class="Menu">
        <ul class="nav1">
           <li class="choosed"><a href="<?php echo site_url().'/index/home/index'?>">首页</li>
           <li><a href="#">关于我们</a>
               <ul class="nav2">
                   <li><a href="<?php echo site_url().'/index/home/introduce'?>">中心简介</a></li>
                   <li><a href="#">服务内容</a></li>
                   <li><a href="#">师资队伍</a></li>
               </ul>
           </li>
           <li><a href="#">新闻公告</a>
               <ul class="nav2">
                   <li><a href="#">中心动态</a></li>
                   <li><a href="#">学院风采</a></li>
                   <li><a href="#">朋辈成长</a></li>
                   <li><a href="#">教师园地</a></li>
               </ul>
           </li>
           <li><a href="#">心理百科</a>
               <ul class="nav2">
                   <li><a href="#">心理常识</a></li>
                   <li><a href="#">最新发现</a></li>
               </ul>
           </li>
           <li><a href="#">心理保健</a>
               <ul class="nav2">
                   <li><a href="#">情感美文</a></li>
                   <li><a href="#">开心一刻</a></li>
               </ul>
           </li>
           <li><a href="#">心理咨询</a>
               <ul class="nav2">
                   <li><a href="#">咨询常识</a></li>
                   <li><a href="#">药品指南</a></li>
               </ul> 
           </li>
           <li><a href="#">心理测评</a>
               <ul class="nav2">
                   <li><a href="#">心灵普查</a></li>
                   <li><a href="#">趣味检测</a></li>
                   <li><a href="#">专业问卷</a></li>
               </ul>
           </li>
           <li><a href="#">专题活动</a></li>
           <li><a href="<?php echo site_url().'/index/home/download'?>">下载中心</a></li>
           <li><a href="<?php echo site_url().'/index/home/LeMesge'?>">我要留言</a></li>
        </ul>
    </div>
    <!-- 新闻公告 -->
    <div class="newslist Cont">
        <div class="sign">
            <span>当前位置：</span>
            <a href="<?php echo base_url().'style/index/'?>">首页</a>
            >>
            <a href="">新闻公告</a>
        </div>
        <ul class="list">
            <?php
                foreach($array as $key =>$v){?>
                        <li>
                            <img src='<?php echo base_url().'style/index/'?>images/list_icon.png' alt='NO FOUND'>
                            <a href=''><?php echo $v->title?></a>
                        </li>
                <?php }
            ?>
            <div class="info">
                <p>共<?php
                    echo $allNum;
                ?>条</p>
                <p><?php
                    echo "{$pageNum}/{$endPage}";
                ?></p>
                <a style="color:black;" href="?pageNum=1" rel="external nofollow" rel="external nofollow" >首页</a>
                <a style="color:black;" href="?pageNum=<?php echo $pageNum==1?1:($pageNum-1)?>" rel="external nofollow" rel="external nofollow" >上页</a>
                <a style="color:black;" href="?pageNum=<?php echo $pageNum==$endPage?$endPage:($pageNum+1)?>" rel="external nofollow" rel="external nofollow" >下页</a>
                <a style="color:black;" href="?pageNum=<?php echo $endPage?>" rel="external nofollow" rel="external nofollow" >尾页</a>   
                <span>跳转至&nbsp<input type='text' id='p' class='p' style='width: 30px;height:15px'>页<button class='btn btn-success' id='b1' style="cursor:pointer;">GO</button></span>
            </div>
        </ul>
        
        <div class="list_img">
            <img src="<?php echo base_url().'style/index/'?>images/newslist.jpg" alt="NO FOUND">
        </div>
        
    </div>
    <!-- 底部FOOT -->
    <div class="footer">
       <pre>河南大学计算机与信息工程学院心理健康教育工作站  地址：河南大学计算机与信息工程学院101</pre>
       <pre>电话：0371-23883169  邮编：475000</pre>
    </div>
</body>
</html>