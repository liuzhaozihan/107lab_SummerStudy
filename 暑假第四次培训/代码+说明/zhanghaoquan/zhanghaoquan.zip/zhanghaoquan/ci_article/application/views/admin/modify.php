<?php
session_start();
@$admin = $_SESSION['user'];
function connectDb()
    {
        $link = mysqli_connect("localhost", "root", "123456");
        if ($link) {
            mysqli_select_db($link, 'user_login');
            mysqli_query($link, "SET NAMES 'utf8'");
        } else {
            echo mysqli_error($link);
        }
        return $link;
    }
    $link = connectDb();
    if(isset($_POST['update'])){
        @$pastword = $_POST['pastword'];
        @$newname = $_POST['newname'];
        @$newword = $_POST['newword'];
        $sql_select = "select username from user where username = '$newname'";
        $pw_url="select password from user where username = '$admin';";
        $pw_sql=mysqli_query($link,$pw_url);
        $pw=mysqli_fetch_row($pw_sql);
        $result=mysqli_query($link,$sql_select);
        $num = mysqli_num_rows($result);
        if(($newword=='')||($pastword=='')){
            echo "<script language=\"JavaScript\">alert(\"密码不能为空\");</script>";
        }
        if(($newname!='')||$num){
            echo "<script language=\"JavaScript\">alert(\"用户名已经存在\");</script>";
        }
        else if($pw[0]!=$pastword){
            echo "<script language=\"JavaScript\">alert(\"旧密码输入有误\");</script>";
        }
        else{
            $pw_update = "update user set password='$newword' where username='$admin';";
            $ret2 = mysqli_query($link,$pw_update);
            if($newname==''){
                $_SESSION['user']=$admin;
            }else{
                $_SESSION['user']=$newname;
                $sql_update = "update user set username='$newname' where username='$admin';";
                $ret = mysqli_query($link,$sql_update);
            }
            echo "<script language=\"JavaScript\">alert(\"修改成功\");</script>";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo base_url().'style/admin/'?>css/public.css" />
</head>
<body>
    <form action="<?php echo site_url('admin/article/modify')?>" method="post">
    <table class="table">
        <tr>
            <td class="th" colspan="10">信息修改</td>
        </tr>
        <tr>
            <td>请输入旧密码</td>
            <td><input type="text" name="pastword" placeholder="请输入旧密码" autocomplete="off"></td>
        </tr>
        <tr>
            <td>请输入新密码</td>
            <td><input type="text" name="newword" placeholder="请输入新密码" autocomplete="off"></td>
        </tr>
        <tr>
            <td>确定提交</td>
            <td><input type="submit"class='input_button' name="update"  autocomplete="off"></td>
        </tr>
    </table>
</body>
</html>