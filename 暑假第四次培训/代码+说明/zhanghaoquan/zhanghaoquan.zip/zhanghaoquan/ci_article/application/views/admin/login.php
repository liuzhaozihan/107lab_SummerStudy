<?php
header("Content-Type: text/html;charset=utf-8");

session_start();
$link = @mysqli_connect('localhost','root','123456');
if($link){
    $select = mysqli_select_db($link,'user_login');
    if($select){
        if(isset($_POST['login'])){
            $user = $_POST['username'];
            $pass = $_POST['password'];
            $_SESSION['user']=$user;
            if(($_POST['authcode'])==''){
                echo "<script language=\"JavaScript\">alert(\"验证码不能为空\");</script>";
            }
            else if(($_POST['authcode']) != $_SESSION['authcode']) {
                echo "<script language=\"JavaScript\">alert(\"验证码输入错误！\");</script>";
            }else{
                if(($user == '')||($pass=='')){
                    echo "<script language=\"JavaScript\">alert(\"用户名或密码输入为空，请重新输入！\");</script>";
                }
                $sql_select = "select username,password from user where username = '$user'";
                mysqli_query($link,'SET NAMES UTF8');
                $ret = mysqli_query($link,$sql_select);
                $row = mysqli_fetch_array($ret); 
                if($user!=$row['username']){
                    echo "<script language=\"JavaScript\">alert(\"用户名输入错误，请重新输入！\");</script>";
                }
                if($pass!=$row['password']){
                    echo "<script language=\"JavaScript\">alert(\"密码输入错误，请重新输入！\");</script>";
                }
                if($user == $row['username']&&$pass == $row['password']){
					success('index/home/index');
                }
            }
        }
    }
    mysqli_close($link);
}else{
    die();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>index-心理健康教育工作站</title>
    <script type="text/javascript" src="<?php echo base_url().'style/admin/'?>js/jquery-3.4.1.js"></script>
    <script type="text/javascript" src="<?php echo base_url().'style/admin/'?>js/js.js"></script>
    <link rel="stylesheet" href="<?php echo base_url().'style/admin/'?>css/login.css">
</head>
<body>
<header>
    <div class="top">
        <img src="<?php echo base_url().'style/admin/'?>images/Henu.jpg" alt="">
        <p>心理健康教育工作站登录系统</p>
    </div>
</header>
<section>
    <div class="background">
        <img src="<?php echo base_url().'style/admin/'?>images/banner1.jpg" alt="">
    </div>
    <div class="logo">
        <img src="<?php echo base_url().'style/admin/'?>images/henu.png" alt="NO FOUND">
        <p>地址：中国 河南 开封.明伦街/金明大道</p>
        <p>邮编：475001/475004 总机号码：0371—22868833</p>
    </div>
    <div class="login">
        <form class="main" action="<?php echo site_url().'/admin/login/index'?>" method="post">
            <div class="head">
                <h2>Henu登录</h2>
            </div>
            <div class="input">
                <div class="user">
                    <img src="<?php echo base_url().'style/admin/'?>images/userlogin.png" alt="NO FOUND"><input type="text" placeholder="用户名" name="username" autocomplete="off">
                </div>
                <div class="user">
                    <img src="<?php echo base_url().'style/admin/'?>images/lock.png" alt="NO FOUND"><input type="password" placeholder="密码" id="word" autocomplete="off" name="password"><img src="<?php echo base_url().'style/admin/'?>images/view.png" alt="NO FOUND" id="view"><img src="<?php echo base_url().'style/admin/'?>images/view_off.png" alt="NO FOUND" id="viewoff">
                </div>
            </div>
            <div class="yzm">
                <a title="点击更换图片" href="javascript:void(0)" rel="external nofollow" onClick="document.getElementById('yzm_img').src='<?php echo site_url().'/admin/login/yzm'?>?r='+Math.random()"><img id="yzm_img" border="1" src="<?php echo site_url().'/admin/login/yzm'?>?r=<?php echo rand(); ?>" width=100 height=30></a>
                <input type="text" name="authcode" id="authcode" autocomplete="off" placeholder="请输入验证码">
            </div>
            <div class="sub">
                <input type="Submit" name="login" value="登陆" />
                <p>还没有账号？<a href="<?php echo site_url().'/admin/login/register'?>">立即注册</a> 或 <a href="<?php echo site_url().'/index/home/index'?>">游客登陆</a></p>
            </div>
        </form>
        <div class="foot">
            <p>其他登录方式</p>
            <img src="<?php echo base_url().'style/admin/'?>images/social_sina.png" alt="NO FOUND">
            <img src="<?php echo base_url().'style/admin/'?>images/social_wechat.png" alt="NO FOUND">
        </div>
    </div>
</section>
<footer>
    <div class="end">
        <p>河南大学计算机与信息工程学院心理健康教育工作站  地址：河南大学计算机与信息工程学院101</p>
        <p>电话：0371-23883169  邮编：475000</p>
    </div>
</footer>
</body>
</html>
