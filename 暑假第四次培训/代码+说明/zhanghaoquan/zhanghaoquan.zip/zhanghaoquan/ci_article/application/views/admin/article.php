<?php
function connectDb()
    {
        $link=mysqli_connect('localhost','root','123456');
        if ($link) {
            mysqli_select_db($link, 'text');
            mysqli_query($link, "SET NAMES 'utf8'");
        } else {
            echo mysqli_error($link);
        }
    return $link;
    }

    $link = connectDb();
    if(isset($_POST['sub'])){
        @$select =$_POST['select'];
        @$email = $_POST['email'];
        @$title = $_POST['title'];
        @$author = $_POST['name'];
        @$date = $_POST['date'];
        @$text = $_POST['content'];
        if($date==''){
            $date =date("Y-m-d");
        }
        $pattern = '^[_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,3}$^';
        if(preg_match($pattern,$email)){
            switch($select){
                case 1:
                    $result = mysqli_query($link,"insert into newslist(title,text,date,author,top) values('$title','$text','$date','$author','0')");
                    echo "<script language=\"JavaScript\">alert(\"发布成功！\");</script>";
                break;
                case 2:
                    $result = mysqli_query($link,"insert into eop(title,text,date,author,top) values('$title','$text','$date','$author','0')");
                    echo "<script language=\"JavaScript\">alert(\"发布成功！\");</script>";
                break;
                case 3:
                    $result = mysqli_query($link,"insert into mh(title,text,date,author,top) values('$title','$text','$date','$author','0')");
                    echo "<script language=\"JavaScript\">alert(\"发布成功！\");</script>";
                break;
                case 4:
                    $result = mysqli_query($link,"insert into pc(title,text,date,author,top) values('$title','$text','$date','$author','0')");
                    echo "<script language=\"JavaScript\">alert(\"发布成功！\");</script>";
                break;
            }
        }else{
            echo "<script language=\"JavaScript\">alert(\"您输入的邮箱格式错误，请重新输入\");</script>";
        }
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'style/admin/css/public.css' ?>">
	<script type="text/javascript" src="<?php echo base_url() ?>org/ueditor/ueditor.all.min.js"></script>
	<script type="text/javascript">
		window.UEDITOR_HOME_URL = "<?php echo base_url() ?>org/ueditor/";
		window.onload = function(){
			window.UEDITOR_CONFIG.initialFrameWidth = 900;
			window.UEDITOR_CONFIG.initialFrameHeight = 600;
			UE.getEditor('content');
		}
	</script>
	<script type="text/javascript" src="<?php echo base_url() ?>org/ueditor/ueditor.config.js"></script>
	<title>Document</title>
	<style type="text/css">
		span{
			color: #f00;
		}
	</style>
</head>
<body>
	<form action="<?php echo site_url('admin/article/send') ?>" method="POST" enctype="multipart/form-data">
	<table class="table">
		<tr >
			<td class="th" colspan="10">发表文章</td>
		</tr>
		<tr>
			<td>作者名</td>
			<td>
				<input type="text" name="name" value="<?php echo set_value('name')?>">
			</td>
		</tr>
		<tr>
			<td>日期</td>
			<td>
				<input type="text" name="date" placeholder="默认为当前时间（可空）" value="<?php echo set_value('date')?>">
			</td>
		</tr>
		<tr>
			<td>邮箱</td>
			<td>
				<input type="text" name="email"/>
			</td>
		</tr>
		<tr>
			<td>栏目</td>
			<td>
				<select name="select">
					<option value="1">新闻公告</option>
                    <option value="2">心理百科</option>
                    <option value="3">心理保健</option>
                    <option value="4">心理咨询</option>
				</select>
			</td>
		</tr>
		<tr>
			<td>标题</td>
			<td><textarea type="text" name="title" style="width:550px;height:100px;resize:none;" value="<?php echo set_value('title') ?>"></textarea>
			<?php echo form_error('title', '<span>', '</span>') ?>
			</td>
		</tr>
		<tr>
			<td>内容</td>
			<td>
				<textarea name="content" id="content" style="width:550px;height:500px;"><?php echo set_value('content') ?></textarea>
				<?php echo form_error('content', '<span>', '</span>') ?>
			</td>
		</tr>
		<tr>
			<td colspan="10"><input type="submit" name="sub" class="input_button" value="发布"/></td>
		</tr>
	</table>
	</form>
</body>
</html>