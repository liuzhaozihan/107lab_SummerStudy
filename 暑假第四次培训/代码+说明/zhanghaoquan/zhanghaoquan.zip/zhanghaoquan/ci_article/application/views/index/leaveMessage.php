<?php
header("content-type:text/html;charset=utf-8");
function connectDb(){
    $link = mysqli_connect("localhost", "root", "123456");
        if ($link) {
            mysqli_select_db($link, 'text');
            mysqli_query($link, "SET NAMES 'utf8'");
        } else {
            echo mysqli_error($link);
        }
    return $link;
}

$link = connectDb();
    @$Message = $_POST['Message'];
    @$email = $_POST['email'];
    if(isset($_POST['sub'])){
        $pattern = '^[_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,3}$^';
        if(preg_match($pattern,$email)){
            $result = mysqli_query($link,"insert into lemesge(title,date) values('$Message',curdate())");
            echo    "<script language=\"JavaScript\">alert(\"留言成功！\");</script>";
        }else{
            echo "<script language=\"JavaScript\">alert(\"您输入的邮箱格式错误，请重新输入\");</script>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>leaveMessage-计算机与信息工程学院官网</title>
    <link rel="stylesheet" href="<?php echo base_url().'style/index/'?>css/public.css">
    <link rel="stylesheet" href="<?php echo base_url().'style/index/'?>css/leaveMessage.css">
    <script text="text/javascript" src="<?php echo base_url().'style/index/'?>js/jquery-3.4.1.js"></script>
    <script text="text/javascript" src="<?php echo base_url().'style/index/'?>js/public.js"></script>
</head>
<body>
    <!-- 顶部选项 -->
    <div class="Header">
        <pre>设为首页 | 加入收藏</pre>
    </div>
    <!-- Logo -->
    <div class="Logo">
       <img src="<?php echo base_url().'style/index/'?>images/ICON.png" alt="NO FOUND">
    </div>
    <!-- 菜单栏 -->
    <div class="Menu">
        <ul class="nav1">
           <li class="choosed"><a href="<?php echo site_url().'/index/home/index'?>">首页</li>
           <li><a href="#">关于我们</a>
               <ul class="nav2">
                   <li><a href="<?php echo site_url().'/index/home/introduce'?>">中心简介</a></li>
                   <li><a href="#">服务内容</a></li>
                   <li><a href="#">师资队伍</a></li>
               </ul>
           </li>
           <li><a href="#">新闻公告</a>
               <ul class="nav2">
                   <li><a href="#">中心动态</a></li>
                   <li><a href="#">学院风采</a></li>
                   <li><a href="#">朋辈成长</a></li>
                   <li><a href="#">教师园地</a></li>
               </ul>
           </li>
           <li><a href="#">心理百科</a>
               <ul class="nav2">
                   <li><a href="#">心理常识</a></li>
                   <li><a href="#">最新发现</a></li>
               </ul>
           </li>
           <li><a href="#">心理保健</a>
               <ul class="nav2">
                   <li><a href="#">情感美文</a></li>
                   <li><a href="#">开心一刻</a></li>
               </ul>
           </li>
           <li><a href="#">心理咨询</a>
               <ul class="nav2">
                   <li><a href="#">咨询常识</a></li>
                   <li><a href="#">药品指南</a></li>
               </ul> 
           </li>
           <li><a href="#">心理测评</a>
               <ul class="nav2">
                   <li><a href="#">心灵普查</a></li>
                   <li><a href="#">趣味检测</a></li>
                   <li><a href="#">专业问卷</a></li>
               </ul>
           </li>
           <li><a href="#">专题活动</a></li>
           <li><a href="<?php echo site_url().'/index/home/download'?>">下载中心</a></li>
           <li><a href="<?php echo site_url().'/index/home/LeMesge'?>">我要留言</a></li>
        </ul>
    </div>
    <!-- 留言框 -->
    <div class="LeMesge Cont">
        <div class="sign">
            <span>当前位置：</span>
            <a href="<?php echo base_url().'style/index/'?>index.php">首页</a>
            >>
            <a href="">我要留言</a>
        </div>
        <p>请编辑留言内容</p>
        <form action="<?php echo site_url().'/index/home/LeMesge'?>" method="post">
            <div class="email">
                请输入您的邮箱：<input type="text" name="email">
            </div>
            请输入留言内容:
            <div class="LeMesge_area">
                <textarea cols="80" rows="20" name="Message"></textarea>
            </div>
            <input type="submit" id="submit" name="sub" value="发布">
        </form>
    </div>
    <!-- 底部FOOT -->
    <div class="footer">
       <pre>河南大学计算机与信息工程学院心理健康教育工作站  地址：河南大学计算机与信息工程学院101</pre>
       <pre>电话：0371-23883169  邮编：475000</pre>
    </div>
</body>
</html>