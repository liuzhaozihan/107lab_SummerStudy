<?php
session_start();
@$user = $_SESSION['user'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
	<title>后盾网后台管理首页</title>
	<link rel="stylesheet" href="<?php echo base_url().'style/admin/'?>css/admin.css" />
	<script type="text/javascript" src="<?php echo base_url().'style/admin/'?>js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url().'style/admin/'?>js/admin.js"></script>
<!-- 默认打开目标 -->
<base target="iframe"/>
</head>
<body>
<!-- 头部 -->
	<div id="top_box">
		<div id="top">
			<p id="top_font">心理健康教育工作站后台管理系统</p>
		</div>
		<div class="top_bar">
			<p class="adm">
				<span>管理员：</span>
				<span class="adm_pic">&nbsp&nbsp&nbsp&nbsp</span>
				<span class="adm_people"><?php echo $user?></span>
				<a href="<?php echo site_url('index/home/index');?>" target="_self">回到首页</a>
			</p>
			<p class="now_time">
				今天是：<?php echo date("yy-m-d")?>
				您的当前位置是：
				<span>首页</span>
			</p>
			<p class="out">
				<span class="out_bg">&nbsp&nbsp&nbsp&nbsp</span>&nbsp
				<a href="<?php echo site_url('admin/login/index');?>" target="_self">退出</a>
			</p>
		</div>
	</div>
<!-- 左侧菜单 -->
	<div id="left_box">
		<p class="use">常用菜单</p>
		<div class="menu_box">
			<h2>文章管理</h2>
			<div class="text">
				<ul class="con">
			        <li class="nav_u">
			        	<a href="<?php echo site_url('admin/article/send_article')?>" class="pos">发表文章</a>				        	
			        </li> 
			    </ul>
				<ul class="con">
			        <li class="nav_u">
			        	<a href="<?php echo site_url('admin/article/newslist')?>" class="pos">新闻公告</a>				        	
			        </li> 
			    </ul>
			    <ul class="con">
			        <li class="nav_u">
			        	<a href="<?php echo site_url('admin/article/eop')?>" class="pos">心理百科</a>				        	
			        </li> 
			    </ul>
			    <ul class="con">
			        <li class="nav_u">
			        	<a href="<?php echo site_url('admin/article/mh')?>" class="pos">心理保健</a>				        	
			        </li> 
			    </ul>
			    <ul class="con">
			        <li class="nav_u">
			        	<a href="<?php echo site_url('admin/article/pc')?>" class="pos">心理咨询</a>				        	
			        </li> 
			    </ul>
			</div>
		</div>	
		<div class="menu_box">
			<h2>常用菜单</h2>
			<div class="text">
				<ul class="con">
			        <li class="nav_u">
			        	<a href="<?php echo site_url('admin/article/banner')?>" class="pos">前台轮播图</a>				        	
			        </li> 
			    </ul>
				<ul class="con">
			        <li class="nav_u">
			        	<a href="<?php echo site_url('admin/article/mate')?>" class="pos">管理员</a>				        	
			        </li> 
			    </ul>
			    <ul class="con">
			        <li class="nav_u">
			        	<a href="<?php echo site_url('admin/article/LeMesge')?>" class="pos">留言查看</a>				        	
			        </li> 
			    </ul>
			    <ul class="con">
			        <li class="nav_u">
			        	<a href="<?php echo site_url('admin/article/download')?>" class="pos">下载中心</a>				        	
			        </li> 
			    </ul>
			    <ul class="con">
			        <li class="nav_u">
			        	<a href="<?php echo site_url('admin/article/modify')?>" class="pos">密码修改</a>				        	
			        </li> 
			    </ul>
			</div>
		</div>	
	</div>
	<!-- 右侧 -->
	<div id="right">
		<iframe  frameboder="0" border="0" 	scrolling="yes" name="iframe" src="<?php echo site_url().'/admin/admin/copy'?>"></iframe>
	</div>
	<!-- 底部 -->
	<div id="foot_box">
		<div class="foot">
			<p>河南大学计算机与信息工程学院心理健康教育工作站  地址：河南大学计算机与信息工程学院101</p>
		</div>
	</div>

</body>
</html>
