<?php
session_start();
if(@$_SESSION['user']==''){
    $to = false;
}else{
    $to = true;
}
    function connectDb()
    {
        $link = mysqli_connect("localhost", "root", "123456");
        if ($link) {
            mysqli_select_db($link, 'text');
            mysqli_query($link, "SET NAMES 'utf8'");
        } else {
            echo mysqli_error($link);
        }
        return $link;
    }

    $link = connectDb();
    $result = mysqli_query($link,'select * from newslist;');
    $result_2 = mysqli_query($link,'select * from eop;');
    $result_3 = mysqli_query($link,'select * from mh;');
    $result_4 = mysqli_query($link,'select * from pc;');
    $result_5 = mysqli_query($link,'select * from download;');

    $rows = array();
    while($row = mysqli_fetch_assoc($result)){
        $rows[] = $row;
    }


    $rows_2 = array();
    while($row_2 = mysqli_fetch_assoc($result_2)){
        $rows_2[] = $row_2;
    }

    $rows_3 = array();
    while($row_3 = mysqli_fetch_assoc($result_3)){
        $rows_3[] = $row_3;
    }

    $rows_4 = array();
    while($row_4 = mysqli_fetch_assoc($result_4)){
        $rows_4[] = $row_4;
    }

    $rows_5 = array();
    while($row_5 = mysqli_fetch_assoc($result_5)){
        $rows_5[] = $row_5;
    }

    $rows = array_reverse($rows);
    $rows_2 = array_reverse($rows_2);
    $rows_3 = array_reverse($rows_3);
    $rows_4 = array_reverse($rows_4);
    $rows_5 = array_reverse($rows_5);

    $newsNum = 0;
    $newsNum_2 = 0;
    $newsNum_3 = 0;
    $newsNum_4 = 0;
    $newsNum_5 = 0;

    $result_img = mysqli_query($link, "SELECT * FROM banner");
    $dataCount_2 = mysqli_num_rows($result_img);
    $show = false;
    $icon=array();
    for ($i = 0; $i < $dataCount_2; $i++) {
        $result_arr = mysqli_fetch_assoc($result_img);
        $icon[]=$result_arr['title'];
        $show = true;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.1">
    <title>心理健康工作站-计算机与信息工程学院官网</title>
    <link rel="stylesheet" href="<?php echo base_url().'style/index/'?>css/swiper-6.0.4/package/swiper-bundle.min.css">
    <link rel="stylesheet" href="<?php echo base_url().'style/index/'?>css/public.css">
    <link rel="stylesheet" href="<?php echo base_url().'style/index/'?>css/index.css">
    <script text="text/javascript" src="<?php echo base_url().'style/index/'?>js/jquery-3.4.1.js"></script>
    <script text="text/javascript" src="<?php echo base_url().'style/index/'?>js/public.js"></script>
</head>
<body>
    <!-- 顶部选项 -->
    <div class="Header">
        <pre>
        <?php
            if($to==false){?>
                <a href='<?php echo site_url().'/admin/login/index'?>'>登录</a>
            <?php }
            ?> 设为首页 | 加入收藏
        </pre>
    </div>
    <!-- Logo -->
    <div class="Logo">
       <img src="<?php echo base_url().'style/index/'?>images/ICON.png" alt="NO FOUND">
    </div>
    <!-- 菜单栏 -->
    <div class="Menu">
        <ul class="nav1">
           <li class="choosed"><a href="#">首页</li>
           <li><a href="#">关于我们</a>
               <ul class="nav2">
                   <li><a href="<?php echo site_url().'/index/home/introduce'?>">中心简介</a></li>
                   <li><a href="#">服务内容</a></li>
                   <li><a href="#">师资队伍</a></li>
               </ul>
           </li>
           <li><a href="#">新闻公告</a>
               <ul class="nav2">
                   <li><a href="#">中心动态</a></li>
                   <li><a href="#">学院风采</a></li>
                   <li><a href="#">朋辈成长</a></li>
                   <li><a href="#">教师园地</a></li>
               </ul>
           </li>
           <li><a href="#">心理百科</a>
               <ul class="nav2">
                   <li><a href="#">心理常识</a></li>
                   <li><a href="#">最新发现</a></li>
               </ul>
           </li>
           <li><a href="#">心理保健</a>
               <ul class="nav2">
                   <li><a href="#">情感美文</a></li>
                   <li><a href="#">开心一刻</a></li>
               </ul>
           </li>
           <li><a href="#">心理咨询</a>
               <ul class="nav2">
                   <li><a href="#">咨询常识</a></li>
                   <li><a href="#">药品指南</a></li>
               </ul> 
           </li>
           <li><a href="#">心理测评</a>
               <ul class="nav2">
                   <li><a href="#">心灵普查</a></li>
                   <li><a href="#">趣味检测</a></li>
                   <li><a href="#">专业问卷</a></li>
               </ul>
           </li>
           <li><a href="#">专题活动</a></li>
           <li><a href="<?php echo site_url().'/index/home/download'?>">下载中心</a></li>
           <li><a href="<?php echo site_url().'/index/home/LeMesge'?>">我要留言</a></li>
        </ul>
    </div>
    <!-- 首页轮播图 -->
    <div class="swiper-container swiper1">
        <div class="swiper-wrapper">
            <?php
                for($i = 0; $i < $dataCount_2; $i++){?>
                <div class='swiper-slide'>
                    <img src="<?php echo base_url().'style/index/'.$icon[$i]?>" alt='NO FOUND'>
                </div>
                <?php }
            ?>
        </div>
        
        <div class="swiper-pagination"></div>
        
    </div>
    <!-- 内容板块 -->
    <div class="Content">
        <!-- 内容上半板块 -->
        <div class="Content_top">
            <div class="swiper-container news_img">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="<?php echo base_url().'style/index/'?>images/news_image1.jpg" alt="NO FOUND">
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php echo base_url().'style/index/'?>images/news_image2.jpg" alt="NO FOUND">
                    </div>
                </div>
                <div class="swiper-pagination"></div>
            </div>
            <div class="news">
                <span class="title">
                    <a href="<?php echo site_url().'/index/home/newslist'?>">新闻公告</a>
                </span>
                <ul>
                    <?php
                        foreach($rows as $key => $v){
                            if($newsNum<8&&$v['top']==1){?>
                                <li>
                                    <img src='<?php echo base_url().'style/index/'?>images/list_icon.png' alt='NO FOUND'>
                                    <a href='<?php echo site_url().'/index/home/newContent';?>'><?php echo "<font color='red'>".$v['title']."</font>"?></a>
                                </li>
                                <?php
                            $newsNum++;
                            }
                        }
                        foreach($rows as $key => $v){
                            if($newsNum<8&&$v['top']==0){?>
                                <li>
                                    <img src='<?php echo base_url().'style/index/'?>images/list_icon.png' alt='NO FOUND'>
                                    <a href='<?php echo site_url().'/index/home/newContent';?>'><?php echo $v['title']?></a>
                                </li>
                                <!-- <a href='php/{$v['title']}'>{$v['title']}</a>  -->
                                <?php
                            $newsNum++;
                            }
                        }
                    ?>
                </ul>
            </div>
        </div>
        <!-- 内容下半板块 -->
        <div class="Content_bottom">
            <div class="introduce">
                <span class="title">
                    <a href="<?php echo site_url().'/index/home/introduce'?>">中心简介</a>
                </span>
                <p>计算机与信息工程学院心理健康教育工作站始建于2015年3月，在学院101办公室，占地面积50平方米。工作站领导小组由学院党委副书记、各年级辅导员、年级朋辈辅导员组成。工作站宗旨以增强学生的心理素质为目的，以普及心理健康知识...<a href="<?php echo site_url().'/index/home/introduce';?>">详情</a></p>
            </div>
            <div class="tab">
                <div class="tab_title">
                    <ul>
                        <li class="tab_select">
                            <a href="<?php echo site_url().'/index/home/eop'?>">心理百科</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url().'/index/home/mh'?>">心理保健</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url().'/index/home/pc'?>">心理咨询</a>
                        </li>
                    </ul>
                </div>
                <div class="tab_ul text">
                    <ul>
                    <?php
                        foreach($rows_2 as $key => $v){
                            if($newsNum_2<5&&$v['top']==1){?>
                            <li>
                                <img src='<?php echo base_url().'style/index/'?>images/list_tabicon.png' alt='NO FOUND'>
                                <a href=''><?php echo "<font color='red'>".$v['title']."</font>"?></a>
                            </li>
                            <?php
                            $newsNum_2++;
                            }
                        }
                        foreach($rows_2 as $key => $v){
                            if($newsNum_2<5&&$v['top']==0){?>
                            <li>
                                <img src='<?php echo base_url().'style/index/'?>images/list_tabicon.png' alt='NO FOUND'>
                                <a href=''><?php echo $v['title']?></a>
                            </li>
                            <?php
                            $newsNum_2++;
                            }
                        }
                    ?>
                    </ul>
                    <ul>
                    <?php
                        foreach($rows_3 as $key => $v){
                            if($newsNum_3<5&&$v['top']==1){?>
                            <li>
                                <img src='<?php echo base_url().'style/index/'?>images/list_tabicon.png' alt='NO FOUND'>
                                <a href=''><?php echo "<font color='red'>".$v['title']."</font>"?></a>
                            </li>
                            <?php
                            $newsNum_3++;
                            }
                        }
                        foreach($rows_3 as $key => $v){
                            if($newsNum_3<5&&$v['top']==0){?>
                            <li>
                                <img src='<?php echo base_url().'style/index/'?>images/list_tabicon.png' alt='NO FOUND'>
                                <a href=''><?php echo $v['title']?></a>
                            </li>
                            <?php
                            $newsNum_3++;
                            }
                        }
                    ?>
                    </ul>
                    <ul>
                    <?php
                        foreach($rows_4 as $key => $v){
                            if($newsNum_4<5&&$v['top']==1){?>
                            <li>
                                <img src='<?php echo base_url().'style/index/'?>images/list_tabicon.png' alt='NO FOUND'>
                                <a href=''><?php echo "<font color='red'>".$v['title']."</font>"?></a>
                            </li>
                            <?php
                            $newsNum_4++;
                            }
                        }
                        foreach($rows_4 as $key => $v){
                            if($newsNum_4<5&&$v['top']==0){?>
                            <li>
                                <img src='<?php echo base_url().'style/index/'?>images/list_tabicon.png' alt='NO FOUND'>
                                <a href=''><?php echo $v['title']?></a>
                            </li>
                            <?php
                            $newsNum_4++;
                            }
                        }
                    ?>
                    </ul>
                </div>
            </div>
            <div class="download">
                <span class="title"><a href="<?php echo site_url().'/index/home/download'?>">下载中心</a></span>
                <ul>
                    <?php
                        foreach($rows_5 as $key => $v){
                            if($newsNum_5<5&&$v['top']==1){?>
                            <li>
                                <img src='<?php echo base_url().'style/index/'?>images/list_tabicon.png' alt='NO FOUND'>
                                <a href=''><?php echo "<font color='red'>".$v['title']."</font>"?></a>
                            </li>
                            <?php
                            $newsNum_5++;
                            }
                        }
                        foreach($rows_5 as $key => $v){
                            if($newsNum_5<5&&$v['top']==0){?>
                            <li>
                                <img src='<?php echo base_url().'style/index/'?>images/list_tabicon.png' alt='NO FOUND'>
                                <a href=''><?php echo $v['title']?></a>
                            </li>
                            <?php
                            $newsNum_5++;
                            }
                        }
                    ?>
                </ul>
            </div>
        </div>
    </div>
    <!-- 底部FOOT -->
    <div class="footer">
        <pre>河南大学计算机与信息工程学院心理健康教育工作站  地址：河南大学计算机与信息工程学院101</pre>
        <pre>电话：0371-23883169  邮编：475000</pre>
    </div>
    <?php
    if($to ==true){?>
        <a href='<?php echo site_url().'/admin/admin/index'?>'>
            <div class='Toadmin'>
                后台
            </div>
        </a><?php
        }
    ?>
    <script src="<?php echo base_url().'style/index/'?>css/swiper-6.0.4/package/swiper-bundle.min.js"></script>
</body>
<script>        
    var swiper = new Swiper('.swiper-container', {
        loop:true,
        spaceBetween: 30,
        effect: 'fade',
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });
</script>
</html>