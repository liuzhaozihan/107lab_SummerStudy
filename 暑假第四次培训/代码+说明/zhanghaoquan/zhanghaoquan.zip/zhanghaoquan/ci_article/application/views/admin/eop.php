<?php
session_start();
@$admin = $_SESSION['user'];
function news($pageNum = 1, $pageSize = 10)
    {
        $array = array();
        $link = mysqli_connect('localhost','root','123456');
        mysqli_set_charset($link,'utf8');
        mysqli_select_db($link,"text");
        $rs = "select * from eop limit " . (($pageNum - 1) * $pageSize) . "," . $pageSize;
        $r = mysqli_query($link, $rs);
        while ($obj = mysqli_fetch_object($r)) {
            $array[] = $obj;
        }
        mysqli_close($link,"text");
        $array = array_reverse($array);
        return $array;
    }
function allNews()
    {
        $link = mysqli_connect('localhost','root','123456');
        mysqli_set_charset($link,'utf8');
        mysqli_select_db($link,"text");
        $rs = "select count(*) num from eop";
        $r = mysqli_query($link, $rs);
        $obj = mysqli_fetch_object($r);
        mysqli_close($link,"text");
        return $obj->num;
    }
function connectDb()
    {
        $link = mysqli_connect("localhost", "root", "123456");
        if ($link) {
            mysqli_select_db($link, 'text');
            mysqli_query($link, "SET NAMES 'utf8'");
        } else {
            echo mysqli_error($link);
        }
        return $link;
    }

    $search = false;
    @$title = $_POST['title'];
    $link = connectDb();
    if($title !=''){
        $result = mysqli_query($link, "SELECT * FROM eop where title like '%$title%'");
        $dataCount = mysqli_num_rows($result);
        $search = true;
    }

    @$id =$_GET['id'];
    mysqli_query($link,"delete from eop where id = '$id';");
    @$zd = $_GET['zd'];
    mysqli_query($link,"update eop set top='1' where id = '$zd';");
    @$qxzd = $_GET['qxzd'];
    if($qxzd!=0){
        mysqli_query($link,"update eop set top='0';");
    }
    
    @$del = $_POST['num'];
    $del_result = mysqli_query($link,"delete from eop where title = '$del';");

    @$allNum = allNews();

    @$pageSize = 10;

    @$pageNum = empty($_GET["pageNum"])?1:$_GET["pageNum"];

    @$endPage = ceil($allNum/$pageSize);

    @$array = news($pageNum,$pageSize);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo base_url().'style/admin/'?>css/public.css" />
    <script>
        $(function () {  
            $('#b1').click(function(){
	        val = $('#p').val();
	        if(!val){
	        	alert('请输入页码！');
		    }else{
		        if(val.match(/^\d+$/g)){
		    	    location='admin.php?pageNum='+val;
		    	}else{
		    	}
		    }
            })
        })
    
    </script>
</head>
<body>
<form action="<?php echo site_url('admin/article/eop') ?>" method="post">
    <table class="table">
        <tr>
            <td class="th" colspan="10">心理百科</td>
        </tr>
        <tr>
            <td>标题</td>
            <td>发表时间</td>
            <td>操作</td>
        </tr>
        <?php
            if($search==true){
                for ($i = 0; $i < $dataCount; $i++) {
                    $result_arr = mysqli_fetch_assoc($result); 
                    $result_arr['title'] = str_replace("$title","<font color='#39A4DB'>$title</font>",$result_arr['title']);?>
                        <tr>
                            <td><?php echo $result_arr['title']?></td>
                            <td><?php echo $result_arr['date']?></td>
                            <td>
                                <a href='<?php echo site_url('admin/article/eop') ?>?id=<?php echo $result_arr['id']?>' name="del">[删除]</a>
                                <a href='<?php echo site_url('admin/article/eop') ?>?zd=<?php echo $result_Arr['id']?>' name="zd">[置顶]</a>
                            </td>
                        </tr>
                <?php }
            }else{
                foreach($array as $key => $v) {
                    if($v->top==1){?>
                        <tr>
                            <td><?php echo "<font color='red'>".$v->title."</font>";?></td>
                            <td><?php echo "<font color='red'>".$v->date."</font>";?></td>
                            <td>
                                <a href='<?php echo site_url('admin/article/eop') ?>?id=<?php echo $v->id?>' name="del">[删除]</a>
                                <a href='<?php echo site_url('admin/article/eop') ?>?qxzd=<?php echo $v->id?>' name="qxzd">[取消置顶]</a>
                            </td>
                        </tr>
                    <?php }
                }
                foreach($array as $key => $v) {
                    if($v->top==0){
                    ?>
                        <tr>
                            <td><?php echo $v->title?></td>
                            <td><?php echo $v->date?></td>
                            <td>
                                <a href='<?php echo site_url('admin/article/eop') ?>?id=<?php echo $v->id?>' name="del">[删除]</a>
                                <a href='<?php echo site_url('admin/article/eop') ?>?zd=<?php echo $v->id?>' name="zd">[置顶]</a>
                            </td>
                        </tr>
                <?php }
                }
            }
            ?>
            <tr>
                <td class="th">查询文章</td>
                <td class="th"><input type="text" placeholder="文章标题关键字" name="title"></td>
                <td class="th"><input type="submit" name="submit"></td>
            </tr>
    </table>
    </form>
    <div class="info">
        <p>共<?php
            echo $allNum;
        ?>条</p>
        <p><?php
            echo "{$pageNum}/{$endPage}";
        ?></p>
        <a style="color:black;" href="?pageNum=1" rel="external nofollow" rel="external nofollow" >首页</a>
        <a style="color:black;" href="?pageNum=<?php echo $pageNum==1?1:($pageNum-1)?>" rel="external nofollow" rel="external nofollow" >上页</a>
        <a style="color:black;" href="?pageNum=<?php echo $pageNum==$endPage?$endPage:($pageNum+1)?>" rel="external nofollow" rel="external nofollow" >下页</a>
        <a style="color:black;" href="?pageNum=<?php echo $endPage?>" rel="external nofollow" rel="external nofollow" >尾页</a>   
        <span>跳转至&nbsp<input type='text' id='p' class='p' style='width: 30px;height:15px'>页<button class='btn btn-success' id='b1' style="cursor:pointer;">GO</button></span>
    </div>
</body>
</html>