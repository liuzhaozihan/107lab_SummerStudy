<?php 
    header("Content-Type:text/html;charset=utf-8");
    $link = @mysqli_connect('localhost','root','123456');
    if($link){
        $select = mysqli_select_db($link,"user_login");
        if(isset($_POST["subr"])){
            $user = $_POST["username"];
            $password = $_POST["password"];
            $re_pass =$_POST["re_password"];

            if(($user == '')||($password == '')){
                echo "<script language=\"JavaScript\">alert(\"用户名或密码不能为空，请重新输入\");</script>";
            }
            if($password==$re_pass){
                mysqli_set_charset($link,'utf8');
                $sql_select = "select username from user where username = '$user'";
                $result=mysqli_query($link,$sql_select);
                $num = mysqli_num_rows($result);
                if($user)
                if($num){
                    echo "<script language=\"JavaScript\">alert(\"用户名已经存在!\");</script>";
                }else{
                    $sql_insert = "insert into user(username,password,autho) values('$user','$password','0')";
                    $ret = mysqli_query($link,$sql_insert);
                    $row = mysqli_fetch_array($ret);
                    header("location:login.php");
                }
            }else{
                echo "<script language=\"JavaScript\">alert(\"两次密码输入不一致！\");</script>";
            }
        }mysqli_close($link);
    }else{
        die();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="<?php echo base_url().'style/admin/'?>js/jquery-3.4.1.js"></script>
    <title>index-心理健康教育工作站</title>
    <link rel="stylesheet" href="<?php echo base_url().'style/admin/'?>css/register.css">
</head>
<body>
<header>
    <div class="top">
        <img src="<?php echo base_url().'style/admin/'?>images/Henu.jpg" alt="">
        <p>心理健康教育工作站注册系统</p>
    </div>
</header>
<section>
    <div class="background">
        <img src="<?php echo base_url().'style/admin/'?>images/banner1.jpg" alt="">
    </div>
    <div class="logo">
        <img src="<?php echo base_url().'style/admin/'?>images/henu.png" alt="NO FOUND">
        <p>地址：中国 河南 开封.明伦街/金明大道</p>
        <p>邮编：475001/475004 总机号码：0371—22868833</p>
    </div>
    <div class="login">
        <form class="main" method="post" action="<?php echo site_url().'/admin/login/register'?>">
            <div class="head">
                <h2>Henu注册</h2>
            </div>
            <div class="input">
                <div class="user">
                    <img src="<?php echo base_url().'style/admin/'?>images/userlogin.png" alt="NO FOUND"><input type="text" placeholder="用户名" name="username" autocomplete="off">
                </div>
                <div class="user">
                    <img src="<?php echo base_url().'style/admin/'?>images/lock.png" alt="NO FOUND"><input type="password" placeholder="密码" id="word" name="password" autocomplete="off">
                </div>
                <div class="user">
                    <img src="<?php echo base_url().'style/admin/'?>images/lock.png" alt="NO FOUND"><input type="password" placeholder="确认密码" id="word" name="re_password" autocomplete="off">
                </div>
            </div>
            <div class="sub">
                <input type="submit" name="subr" value="注册" /> 
            </div>
        </form>
        <div class="backto">
            <a href="<?php echo site_url().'/admin/login/index'?>">返回</a>
        </div>
    </div>
</section>
<footer>
    <div class="end">
        <p>河南大学计算机与信息工程学院心理健康教育工作站  地址：河南大学计算机与信息工程学院101</p>
        <p>电话：0371-23883169  邮编：475000</p>
    </div>
</footer>
</body>
</html>