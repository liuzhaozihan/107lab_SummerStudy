<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'style/admin/css/public.css' ?>">
	<script type="text/javascript" src="<?php echo base_url() ?>org/ueditor/ueditor.all.min.js"></script>
	<script type="text/javascript">
		window.UEDITOR_HOME_URL = "<?php echo base_url() ?>org/ueditor/";
		window.onload = function(){
			window.UEDITOR_CONFIG.initialFrameWidth = 900;
			window.UEDITOR_CONFIG.initialFrameHeight = 600;
			UE.getEditor('content');
		}
	</script>
	<script type="text/javascript" src="<?php echo base_url() ?>org/ueditor/ueditor.config.js"></script>
	<title>Document</title>
	<style type="text/css">
		span{
			color: #f00;
		}
	</style>
</head>
<body>
	<form action="<?php echo site_url('admin/article/edit') ?>" method="POST" enctype="multipart/form-data">
	<table class="table">
		<tr >
			<td class="th" colspan="10">发表文章</td>
		</tr>
		<tr>
			<td>标题</td>
			<td><input type="text" name="title" value="<?php echo set_value('title') ?>"/>
			<?php echo form_error('title', '<span>', '</span>') ?>
			</td>
		</tr>
		<tr>
			<td>作者名</td>
			<td>
				<input type="text" name="name" value="<?php echo set_value('name')?>">
			</td>
		</tr>
		<tr>
			<td>日期</td>
			<td>
				<input type="text" name="date" placeholder="默认为当前时间（可空）" value="<?php echo set_value('date')?>">
			</td>
		</tr>
		<tr>
			<td>栏目</td>
			<td>
				<select name="cid" id="">
					<?php foreach($category as $v): ?>
					<option value="<?php echo $v['cid'] ?>"<?php echo set_select('cid', $v['cid']) ?>><?php echo $v['cname'] ?></option>
					<?php endforeach ?>
				</select>
			</td>
		</tr>
		<tr>
			<td>图片</td>
			<td>
				<input type="file" name="thumb"/>
			</td>
		</tr>
		<tr>
			<td>摘要</td>
			<td>
				<textarea name="info" id="" style="width:550px;height:160px;"><?php echo set_value('info') ?></textarea><?php echo form_error('info', '<span>', '</span>') ?>
			</td>
		</tr>
		<tr>
			<td>内容</td>
			<td>
				<textarea name="content" id="content" style="width:550px;height:500px;"><?php echo set_value('content') ?></textarea>
				<?php echo form_error('content', '<span>', '</span>') ?>
			</td>
		</tr>
		<tr>
			<td colspan="10"><input type="submit" class="input_button" value="发布"/></td>
		</tr>
	</table>
	</form>
</body>
</html>