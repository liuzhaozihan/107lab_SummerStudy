<?php
function connectDb()
    {
        $link = mysqli_connect('localhost','root','123456');
        if($link){
            mysqli_select_db($link,'text');
            mysqli_query($link,"SET NAMES utf8");
        }else{
            echo mysqli_error($link);
        }
        return $link;
    }

    $link = connectDb();
    $result = mysqli_query($link,"select * from newslist;");
    $rows= array();
    while($row = mysqli_fetch_object($result)){
        $rows[]=$row;
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>newContent-计算机与信息工程学院官网</title>
    <link rel="stylesheet" href="<?php echo base_url().'style/index/'?>css/public.css">
    <link rel="stylesheet" href="<?php echo base_url().'style/index/'?>css/newcontent.css">
    <script text="text/javascript" src="<?php echo base_url().'style/index/'?>js/jquery-3.4.1.js"></script>
    <script text="text/javascript" src="<?php echo base_url().'style/index/'?>js/public.js"></script>
</head>
<body>
    <!-- 顶部选项 -->
    <div class="Header">
        <pre>设为首页 | 加入收藏</pre>
    </div>
    <!-- Logo -->
    <div class="Logo">
       <img src="<?php echo base_url().'style/index/'?>images/ICON.png" alt="NO FOUND">
    </div>
    <!-- 菜单栏 -->
    <div class="Menu">
        <ul class="nav1">
           <li class="choosed"><a href="<?php echo site_url().'/index/home/index'?>">首页</li>
           <li><a href="#">关于我们</a>
               <ul class="nav2">
                   <li><a href="<?php echo site_url().'/index/home/introduce'?>">中心简介</a></li>
                   <li><a href="#">服务内容</a></li>
                   <li><a href="#">师资队伍</a></li>
               </ul>
           </li>
           <li><a href="#">新闻公告</a>
               <ul class="nav2">
                   <li><a href="#">中心动态</a></li>
                   <li><a href="#">学院风采</a></li>
                   <li><a href="#">朋辈成长</a></li>
                   <li><a href="#">教师园地</a></li>
               </ul>
           </li>
           <li><a href="#">心理百科</a>
               <ul class="nav2">
                   <li><a href="#">心理常识</a></li>
                   <li><a href="#">最新发现</a></li>
               </ul>
           </li>
           <li><a href="#">心理保健</a>
               <ul class="nav2">
                   <li><a href="#">情感美文</a></li>
                   <li><a href="#">开心一刻</a></li>
               </ul>
           </li>
           <li><a href="#">心理咨询</a>
               <ul class="nav2">
                   <li><a href="#">咨询常识</a></li>
                   <li><a href="#">药品指南</a></li>
               </ul> 
           </li>
           <li><a href="#">心理测评</a>
               <ul class="nav2">
                   <li><a href="#">心灵普查</a></li>
                   <li><a href="#">趣味检测</a></li>
                   <li><a href="#">专业问卷</a></li>
               </ul>
           </li>
           <li><a href="#">专题活动</a></li>
           <li><a href="<?php echo site_url().'/index/home/download'?>">下载中心</a></li>
           <li><a href="<?php echo site_url().'/index/home/LeMesge'?>">我要留言</a></li>
        </ul>
    </div>
    <!-- 正文 -->
    <div class="newcontent Cont">
        <div class="sign">
            <span>当前位置：</span>
            <a href="<?php echo site_url().'/index/home/index'?>">首页</a>
            >>
            <a href="">新闻公告</a>
            >>
            <a href="">正文</a>
        </div>
        <h3><?php echo $rows[0]->title?></h3>
        <pre>
        <span><?php echo '日期：'.$rows[0]->date.' 作者：'.$rows[0]->author?></span><br>
        阅读量：
        </pre>
        <?php echo $rows[0]->text;?>
    </div>
    <!-- 底部FOOT -->
    <div class="footer">
       <pre>河南大学计算机与信息工程学院心理健康教育工作站  地址：河南大学计算机与信息工程学院101</pre>
       <pre>电话：0371-23883169  邮编：475000</pre>
    </div>
</body>
</html>