$(function () {  
    /* Menu菜单栏 */
    var First = $(".nav1>li");
    First.hover(function () {  
        $(this).children(".nav2").stop().slideToggle();
    })
    First.mouseover(function () {  
        $(this).addClass('choosed').siblings().removeClass('choosed');
    }).mouseout(function () {  
        $(".nav1>li:eq(0)").addClass('choosed').siblings().removeClass('choosed');
    })

    /* tab选项卡 */
    $(".tab_ul ul:eq(0)").show();
    $(".tab_title>ul>li").hover(function () {  
        $(this).addClass('tab_select').siblings().removeClass('tab_select');
        $(".tab_ul ul").eq($(this).index()).fadeIn(500).siblings().fadeOut(0);
    })
})