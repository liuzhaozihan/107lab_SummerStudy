<?php
$link = new mysqli('localhost', 'root', 'root', 'test');
$link->set_charset('utf8');
if ($link->connect_error) {
  echo "<script>alert('数据连接失误');";
}
$id = $_GET['id'];
$sql = "select * from news where id='$id'";
$res = $link->query($sql);
if ($res) {
  $row = $res->fetch_assoc();
} else {
  echo "?????";
}
$link->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>编辑新闻</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, Helvetica, sans-serif, 'Courier New', Courier, monospace;
      font-size: 18px;
    }

    table {
      width: 40%;
      margin: 100px auto;
      background-color: #D6E8F4;
      border: 2px;
      text-align: justify;
    }


    a {
      text-decoration: none;
      color: black;
    }
  </style>
</head>

<body>
  <form action="edit_news_action.php?id=<?php echo $row['id']; ?>" method="POST">
    <table border="1">
      <tr>
        <td class="left">编辑标题</td>
        <td class="right"><input style="height: 30px; width:80%;font-size:16px;" type="text" name="title" value="<?php echo $row['title']; ?>"></td>
      </tr>
      <tr>
        <td class="left">编辑内容</td>
        <td class="right"><textarea rows="30" cols="80" name="content"><?php echo $row['content']; ?></textarea></td>
      </tr>
      <tr>
        <td colspan="2" align="center">
          <input type="submit" name="submit" value="提交修改" style="height: 30px; width:90px;font-size:16px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input type="reset" value="重置" style="height: 30px; width:60px;font-size:16px;">
        </td>
      </tr>
    </table>
  </form>
</body>

</html>