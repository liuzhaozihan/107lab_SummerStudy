<?php
$link = new mysqli('localhost', 'root', 'root', 'test');
if ($link->connect_errno) {
  echo '连接失败' . $link->connection_status;
  echo '请稍后尝试';
  exit(0);
}
$link->set_charset('utf8');
$username = $_GET['username'];
$sql = "select * from user where username='$username' ";
$res = $link->query($sql);
if ($res) {
  $ans = $res->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>login</title>
  <style>
    * {
      margin: 0;
      padding: 0;
    }

    body {
      min-width: 1200px;
      font-size: 15px;
      font-family: 'Courier New', Courier, monospace;
    }

    a {
      text-decoration: none;
      color: green;
      font-size: 18px;
    }

    form {
      width: 25%;
      height: 300px;
      background-color: #D6E8F4;
      margin: auto;
      opacity: 0.8;
      box-shadow: 3px 3px 3px 3px grey;
    }

    #login {
      padding-top: 10px;
      display: block;
      font-size: 30px;
    }

    input {
      width: 60%;
      height: 25px;
      margin: 15px;
      border: 1px solid black;
      border-radius: 5px;
      outline: none;
      padding-left: 10px;
    }

    span {
      display: inline-block;
      font-size: 30px;
      margin-top: 15px;
    }
  </style>
</head>

<body>
  <div style="width: 100%;height:150px;"></div>
  <form action="user_edit_action.php?id=<?php echo $ans['id']; ?>" method="POST">
    <center>
      <span id="login?id=<?php $row['id']; ?>">修改账号信息</span>
      <input type="text" name="username" required placeholder="新名称">
      <input type="password" name="password" required placeholder="新密码">
      <input type="password" name="repassword" required placeholder="确认新密码">
      <input type="submit" value="确认修改" style="background-color:green;">
    </center>
  </form>
  <div style="width: 100%;height:150px;"></div>
</body>
<script>
</script>

</html>