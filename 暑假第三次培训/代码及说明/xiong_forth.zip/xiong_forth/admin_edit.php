<?php
$link = new mysqli('localhost', 'root', 'root', 'test');
if ($link->connect_errno) {
  echo '连接失败' . $link->connection_status;
  echo '请稍后在进行尝试';
  exit(0);
}
$link->set_charset('utf-8');
$username = $_GET['username'];
$sql = "select * from admin where username='$username' ";
$res = $link->query($sql);
if ($res) {
  $ans = $res->fetch_assoc();
}
$link->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>login</title>
  <style>
    * {
      margin: 0;
      padding: 0;
    }

    body {
      min-width: 1200px;
      /* background-color: lightgreen; */
      font-size: 15px;
      font-family: 'Courier New', Courier, monospace;
    }

    a {
      text-decoration: none;
      color: green;
      font-size: 18px;
    }

    form {
      width: 25%;
      height: 300px;
      background-color: lightskyblue;
      margin: auto;
      opacity: 0.9;
      box-shadow: 5px 5px 5px 5px grey;
    }


    input {
      width: 60%;
      height: 25px;
      margin: 15px;
      border: 1px solid black;
      border-radius: 10px;
      outline: none;
      padding-left: 10px;
    }

    span {
      display: inline-block;
      font-size: 30px;
      margin-top: 20px;
    }
  </style>
</head>

<body>
  <div style="width: 100%;height:150px;"></div>
  <form action="admin_edit_action.php?id=<?php echo $ans['id']; ?>&oldusername=<?php echo $ans['username']; ?>" method="POST">
    <center>
      <span id="login?id=<?php $row['id']; ?>">修改账号信息</span>
      <input type="text" name="username" required placeholder="新名称">
      <input type="password" name="password" required placeholder="新密码">
      <input type="password" name="repassword" required placeholder="确认新密码">
      <input type="submit" value="确认修改" style="background-color: green;color: white;">
    </center>
  </form>
  <div style="width: 100%;height:150px;"></div>
</body>
<script>
</script>

</html>