<?php
$link = new mysqli('localhost', 'root', 'root', 'test');
if ($link->connect_errno) {
  die('连接失败' . $link->connect_error);
}
$link->set_charset('utf8');
$id = $_GET['id'];
$sql = "select * from user where id=" . $id;
$res = $link->query($sql);
if ($res) {
  $row = $res->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>管理网站用户</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, Helvetica, sans-serif, 'Courier New', Courier, monospace;
      font-size: 18px;
    }

    form {
      width: 25%;
      height: 300px;
      background-color: #D6E8F4;
      margin: auto;
      opacity: 0.8;
      box-shadow: 3px 3px 3px 3px grey;
    }

    input {
      width: 60%;
      height: 25px;
      margin: 20px;
      border: 1px solid black;
      border-radius: 10px;
      outline: none;
      display: block;
      padding-left: 10px;
    }
  </style>
</head>

<body>
  <div style="width: 100%;height:150px;"></div>
  <form action="updateuser_action.php?id=<?php echo $row['id']; ?>" method="post">
    <center>
      <span style="display: block;font-size:30px;padding-top:20px;">修改用户信息</span>
      <input type="text" name="username" placeholder="新用户名" required>
      <input type="text" name="password" placeholder="新密码" required>
      <input type="submit" value="提交编辑" style="background-color: green;color:ivory;">
    </center>
  </form>
</body>

</html>