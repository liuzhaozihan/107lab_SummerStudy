<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>register</title>
  <style>
    * {
      margin: 0;
      padding: 0;
    }

    body {
      min-width: 1200px;
      /* background-color: lightgreen; */
      font-size: 15px;
      font-family: 'Courier New', Courier, monospace;
    }

    a {
      text-decoration: none;
      color: green;
      font-size: 18px;
    }

    form {
      width: 30%;
      height: 380px;
      background-color: #D6E8F4;
      margin: auto;
      opacity: 0.8;
      box-shadow: 3px 3px 3px 3px grey;
    }

    #login {
      padding-top: 20px;
      display: block;
      font-size: 30px;
    }

    #choice {
      width: 5%;
      height: 15px;
      display: inline-block;
      margin: 15px 5px;
      border: 1px solid black;
      border-radius: 10px;
      outline: none;
    }

    input {
      width: 60%;
      height: 25px;
      margin: 15px;
      border: 1px solid black;
      border-radius: 10px;
      outline: none;
    }

    span {
      display: inline-block;
    }
  </style>
</head>

<body>
  <div style="width: 100%;height:150px;"></div>
  <form action="registeraction.php" method="POST">
    <center>
      <span id="login">注册账号</span>
      <input type="radio" name="grade" required value="admin" id="choice">管理员
      <input type="radio" name="grade" required value="user" id="choice" checked>普通用户
      <input type="text" name="username" required placeholder="用户名" style="padding-left: 10px;">
      <input type="password" name="password" required placeholder="设置密码" style="padding-left: 10px;">
      <input type="password" name="repassword" required placeholder="再次输入密码" style="padding-left: 10px;">
      <input type="submit" value="注册" style="background-color: green;color: white;">
    </center>
  </form>
  <div style="width: 100%;height:150px;"></div>
</body>

</html>