<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>admin_login</title>
  <style>
    * {
      margin: 0;
      padding: 0;
    }

    body {
      min-width: 1200px;
      font-size: 15px;
      font-family: 'Courier New', Courier, monospace;
    }

    a {
      text-decoration: none;
      color: green;
      font-size: 18px;
    }

    form {
      width: 25%;
      height: 300px;
      background-color: #D6E8F4;
      margin: auto;
      opacity: 0.8;
      box-shadow: 5px 5px 5px 5px grey;
    }

    #login {
      padding-top: 20px;
      display: block;
      font-size: 30px;
    }

    input {
      width: 60%;
      height: 25px;
      margin: 20px;
      border: 1px solid black;
      border-radius: 7px;
      outline: none;
    }
  </style>
</head>

<body>
  <div style="width: 100%;height:150px;"></div>
  <form action="admin_login_check.php" method="POST">
    <center>
      <span id="login">管理员登录</span>
      <input type="text" name="username" placeholder="用户名" style="padding-left: 10px;">
      <input type="password" name="password" placeholder="密码" style="padding-left: 10px;">
      <input type="submit" value="登录" style="background-color: green;color: white;">
    </center>
  </form>
  <div style="width: 100%;height:150px;"></div>
</body>

</html>