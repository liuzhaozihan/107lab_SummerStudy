<?php
$link = new mysqli('localhost', 'root', 'root', 'test');

if ($link->connect_error) {
  echo "<script>alert('数据连接失误');";
}
// $username=$_GET['username'];
$link->set_charset('utf8');
// if(empty($username))
// {
// 	echo "<script>alert('你应该网站管理员登陆后访问');
// 		location = 'admin_login.php';
// 	</script>";
// 	exit(0);
// }
$sql = "select * from user";
$res = $link->query($sql);
if ($res) {
  while ($row = $res->fetch_assoc()) {
    $rows[] = $row;
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>管理用户</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, Helvetica, sans-serif, 'Courier New', Courier, monospace;
      font-size: 18px;
    }

    table {
      width: 45%;
      margin: 100px auto;
      border: 2px;
      text-align: center;
    }

    a {
      text-decoration: none;
      color: black;
    }
  </style>
</head>

<body>
  <table border="1" bgcolor="#abcdef" cellpadding="0">
    <tr>
      <td colspan='4'><a href="adduser.php">点击创建新用户</a></td>
    </tr>
    <tr>
      <td>编号</td>
      <td>用户名</td>
      <td>密码</td>
      <td>管理</td>
    </tr>
    <?php $i = 1;
    foreach ($rows as $value) : ?>
      <tr>
        <td><?php echo $i; ?></td>
        <td><?php echo $value['username']; ?></td>
        <td><?php echo $value['password']; ?></td>
        <td><a href="updateuser.php?id=<?php echo $value['id']; ?>">更新&nbsp;</a>|<a href="deluser.php?id=<?php echo $value['id']; ?>">&nbsp;删除</a></td>
      </tr>
    <?php $i++;
    endforeach; ?>
  </table>
</body>

</html>