<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>添加新闻</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, Helvetica, sans-serif, 'Courier New', Courier, monospace;
      font-size: 18px;
    }

    table {
      width: 40%;
      margin: 100px auto;
      border: 2px solid black;
      text-align: justify;
    }

    .left {
      padding-left: 100px;
    }

    a {
      text-decoration: none;
      color: black;
    }

    input {
      height: 30px;
      width: 60px;
      font-size: 16px;
      font-weight: 300;
    }

    #news_title {
      width: 80%;
    }
  </style>
</head>

<body>
  <form action="addnews_action.php" method="POST">
    <table border="1">
      <tr>
        <td align="center">
          <a href="newstitlelook.php" target="_blank">管理已发布的新闻</a>
        </td>
        <td align="center">
          <a href="more/morelist.php" target="_blank">查看页面新闻</a>
        </td>
      </tr>
      <tr>
        <td class="left">标题</td>
        <td class="right"><input id="news_title" type="text" name="title"></td>
      </tr>
      <tr>
        <td class="left">内容</td>
        <td class="right"><textarea rows="25" cols="70" name="content" style="font-size: 16px;"></textarea></td>
      </tr>
      <tr>
        <td colspan="2" align="center">
          <input type="submit" name="submit" value="发布">
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <input type="reset" value="重置">
        </td>
      </tr>
    </table>
  </form>
</body>

</html>