<?php


namespace app\utils;


class JsonResponse
{
    private $status;
    private $text;
    private $data=array();


    public function setStatus($status): void
    {
        $this->status = $status;
    }

    public function setText($text): void
    {
        $this->text = $text;
    }

    public function pushData($key,$value): void
    {
        $this->data[$key]=$value;
    }

    public function getResult(): array
    {
        $result = array(
            "status" => $this->status
        );
        if (!empty($this->text)) {
            $result['text']=$this->text;
        }
        if (!empty($this->data)) {
            $result['data']=$this->data;
        }
        return $result;
    }
}