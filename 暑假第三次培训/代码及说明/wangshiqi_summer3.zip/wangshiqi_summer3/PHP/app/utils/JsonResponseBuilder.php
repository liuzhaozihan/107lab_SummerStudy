<?php


namespace app\utils;

use app\utils\JsonResponse;

/**
 * Json响应的构造者类
 * Class JsonResponseBuilder
 * @package app\utils
 */
class JsonResponseBuilder
{
    private $Response;

    //
    public function __construct()
    {
        $this->Response = new JsonResponse();
    }

    public function success()
    {
        $this->Response->setStatus(0);
        return $this;
    }

    public function failed()
    {
        $this->Response->setStatus(1);
        return $this;
    }

    public function text(string $text)
    {
        $this->Response->setText($text);
        return $this;
    }

    public function addData($key,$value)
    {
        $this->Response->pushData($key,$value);
        return $this;
    }

    public function build()
    {
        return $this->Response->getResult();
    }
}