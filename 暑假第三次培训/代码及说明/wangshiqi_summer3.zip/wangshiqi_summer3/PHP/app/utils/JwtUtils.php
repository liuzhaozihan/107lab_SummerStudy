<?php


namespace app\utils;


use Firebase\JWT\JWT;

class JwtUtils
{
    private static $KEY = 'TITAN_KEY_ABC123';

    /**
     * @param array $data 要加密的数据
     * @param int $expire Token的过期时间
     */
    public static function encode(array $data, int $expire = 7200)
    {
        $payload = array(
            "iss" => "Titan",
            "aud" => "Titan",
            "iat" => time(),
            'exp' => time() + $expire,
            "data" => json_encode($data)
        );
        return JWT::encode($payload, self::$KEY);
    }

    /**
     * @param string $token 要解密的Token
     * @return array    加密时存入的数组数据
     */
    public static function decode(string $token)
    {
        $decoded = (array)JWT::decode($token, self::$KEY, array('HS256'));
        return (array)json_decode($decoded['data']);
    }
}