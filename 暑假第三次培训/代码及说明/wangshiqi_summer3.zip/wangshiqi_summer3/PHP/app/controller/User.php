<?php


namespace app\controller;


use app\middleware\AuthCheck;
use app\service\UserService;
use app\utils\JsonResponseBuilder;
use app\utils\JwtUtils;

class User
{
    protected $middleware = [AuthCheck::class];

    /**
     * 获取用户信息
     * 返回的是当前用户的用户名和权限信息
     * 传入的为登录时生成的Token
     * @return \think\response\Json 返回JSON数据
     */
    public function getUserInfo()
    {
        $builder = new JsonResponseBuilder();
        $token = request()->param('token');
        $uid = JwtUtils::decode($token)['uid'];
        $currentUser = UserService::findById($uid);
        $userInfo = array(
            'username' => $currentUser['username'],
            'permission' => $currentUser['permission']
        );
        return json($builder->success()->addData('info', $userInfo)->build());
    }

    public function modify()
    {
        $builder = new JsonResponseBuilder();
        $username = request()->param('username');
        $password = request()->param('password');
        $permission = request()->param('permission', 0);

        $token = request()->param('token');
        $uid = JwtUtils::decode($token)['uid'];
        $currentUser = UserService::findById($uid);

        // 判断其权限，如果权限为 0 且试图修改非本账号，则返回拒绝
        if ($currentUser['permission'] === 0 && $currentUser['username'] !== $username) {
            return json($builder->failed()->text("You don't have permission to modify other user!")->build());
        }
        if (!UserService::saveUser($username, $password, $permission)) {
            return json($builder->failed()->text("Modify user failed!")->build());
        }
        return json($builder->success()->text("Modify user successfully!")->build());
    }
}