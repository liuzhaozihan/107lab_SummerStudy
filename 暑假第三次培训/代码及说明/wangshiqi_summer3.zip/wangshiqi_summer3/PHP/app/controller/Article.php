<?php


namespace app\controller;


use app\BaseController;
use app\middleware\AuthCheck;
use app\service\ArticleService;
use app\service\UserService;
use app\utils\JsonResponseBuilder;
use app\utils\JwtUtils;

class Article extends BaseController
{
    protected $middleware = [AuthCheck::class];
    /**
     * 获取数据库中所有的文章信息
     * 包括: 序号、标题、作者、发表时间、内容、权重
     * @return \think\response\Json
     */
    public function findAll()
    {
        $builder = new JsonResponseBuilder();
        $articles = json_encode(ArticleService::findAll());
        return json($builder->success()
            ->addData('articles', $articles)
            ->build()
        );
    }
    public function findById(){
        $builder = new JsonResponseBuilder();
        $aid = request()->param('aid');
        $article = json_encode(ArticleService::findById($aid));
        return json($builder->success()->addData('article',$article)->build());
    }
    /**
     * 获取数据库中所有的文章列表信息
     * 包括: 序号、标题、作者、发表时间、权重
     * 无：内容
     * @return \think\response\Json
     */
    public function getList()
    {
        $builder = new JsonResponseBuilder();
        $articles = json_encode(ArticleService::getList());
        return json($builder->success()
            ->addData('list', $articles)
            ->build()
        );
    }

    public function post()
    {
        $builder = new JsonResponseBuilder();
        $token = request()->param('token');
        $uid = JwtUtils::decode($token)['uid'];
        $user = UserService::findById($uid);
        $author = $user['username'];
        $title = request()->param('title');
        $content = request()->param('content');
        if (empty($author) || empty($title) || empty($content)) {
            return json($builder->failed()->text('Invalid params!')->build());
        }
        $result = ArticleService::post($title, $author, $content);
        if (!$result) {
            return json($builder->failed()->text('Post failed!')->build());
        }
        return json($builder->success()->text('Post successfully!')->build());
    }


    public function modify()
    {
        $builder = new JsonResponseBuilder();
        $articleId = request()->param('aid');
        $author = request()->param('author');
        $title = request()->param('title');
        $content = request()->param('content');
        $weight = request()->param('weight', 0);
        if (empty($articleId) || empty($author) || empty($title) || empty($content)) {
            return json(
                $builder->failed()
                    ->text('params invalid!')
                    ->build()
            );
        }
        if (!ArticleService::modify($articleId, $author, $title, $content, $weight)) {
            return json(
                $builder->failed()
                    ->text('Modify the article failed!')
                    ->build()
            );
        } else {
            return json(
                $builder->success()
                    ->text('Modify the article successfully!')
                    ->build()
            );
        }
    }

    public function delete()
    {
        $builder = new JsonResponseBuilder();
        $articleId = request()->param('aid');
        if (empty($articleId)) {
            return json(
                $builder->failed()
                    ->text('params invalid!')
                    ->build()
            );
        }
        if (ArticleService::delete($articleId)) {
            return json(
                $builder->failed()
                    ->text('Delete article failed!')
                    ->build()
            );
        }
        return json(
            $builder->success()
                ->text('Delete article successfully!')
                ->build()
        );
    }
}