<?php


namespace app\controller;

use app\BaseController;
use app\service\UserService;
use app\utils\JsonResponseBuilder;
use app\utils\JwtUtils;

class Auth extends BaseController
{
    public function login()
    {
        $builder = new JsonResponseBuilder();
        $username = request()->param('username');
        $password = request()->param('password');
        if (empty($username) || empty($password)) {
            return json($builder->failed()->text("Invalid username or password")->build());
        }
        // 转义HTML字符,防止XSS攻击
        $username = htmlentities($username);
        $password = htmlentities($password);
        $user = UserService::checkUser($username, $password);
        if (empty($user)) {
            return json($builder->failed()->text("Login failed, check your username and password.")->build());
        }
        $token = JwtUtils::encode(["uid" => $user['id']]);
        return json($builder->success()
            ->text('Login successfully')
            ->addData('token', $token)
            ->build()
        );
    }

    public function register()
    {
        $builder = new JsonResponseBuilder();
        $username = request()->param('username');
        $password = request()->param('password');
        if (empty($username) || empty($password)) {
            return json($builder->failed()->text("Invalid username or password")->build());
        }
        // 转义HTML字符,防止XSS攻击
        $username = htmlentities($username);
        $password = htmlentities($password);
        // 查找用户,判断用户是否已经存在
        $user = UserService::findUser($username);
        if ($user !== null) {
            return json($builder->failed()->text("User already exists")->build());
        }
        $result = UserService::saveUser($username, $password);
        if (!$result) {
            return json($builder->failed()->text("Sign up failed!")->build());
        }
        return json($builder->success()->text("Sign up successfully!")->build());
    }

}