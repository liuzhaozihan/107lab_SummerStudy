<?php
declare (strict_types=1);

namespace app\middleware;

use app\utils\JsonResponseBuilder;
use app\utils\JwtUtils;

class AuthCheck
{
    /**
     * 处理请求
     *
     * @param \think\Request $request
     * @param \Closure $next
     * @return \think\response\Json
     */
    public function handle($request, \Closure $next)
    {
        $builder = new JsonResponseBuilder();
        $token = $request->param('token');
        try {
            JwtUtils::decode($token);
        } catch (\Exception $e) {
            return json(
                $builder->failed()->text('Invalid Token!')->build(), 403
            );
        }
        return $next($request);
    }
}
