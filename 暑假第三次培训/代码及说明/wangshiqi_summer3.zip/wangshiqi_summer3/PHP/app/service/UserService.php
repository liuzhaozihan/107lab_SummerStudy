<?php


namespace app\service;

use think\facade\Db;

class UserService
{
    /**
     * @param string $username 用户名
     * @return array|\think\Model|null 返回查询到的用户信息 or Null
     */
    public static function findUser(string $username)
    {
        try {
            return Db::name('user')->where([
                'username' => $username
            ])->find();
        } catch (\Exception $e) {
            return null;
        }
    }

    public static function findById(int $id)
    {
        try {
            return Db::name('user')->where([
                'id' => $id
            ])->find();
        } catch (\Exception $e) {
            return null;
        }
    }

    public static function checkUser(string $username, string $password)
    {
        try {
            return Db::name('user')->where([
                'username' => $username,
                'password' => $password
            ])->find();
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * @param string $username
     * @param string $password
     * @param int $permission
     * @return bool 返回保存用户操作的结果
     */
    public static function saveUser(string $username, string $password, int $permission = 0)
    {
        try {
            Db::name('user')->where(
                'username', $username
            )->update(
                ['password' => $password, 'permission' => $permission]
            );
            return true;
        } catch (\Exception $e) {
            print $e;
            return false;
        }
    }
}