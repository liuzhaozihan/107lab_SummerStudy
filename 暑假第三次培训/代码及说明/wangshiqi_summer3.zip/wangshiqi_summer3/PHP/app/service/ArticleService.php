<?php


namespace app\service;


use think\db\exception\DbException;
use think\facade\Db;

class ArticleService
{
    public static function findAll()
    {
        try {
            return Db::name('article')
                ->order('weight', 'desc')
                ->select()
                ->toArray();
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * 获取某个文章的详细数据
     * @param int $aid 文章ID
     * @return array|null 返回值为文章数组或 NULL
     */
    public static function findById(int $aid)
    {
        try {
            return Db::name('article')
                ->where('id', $aid)
                ->find();
        } catch (\Exception $e) {
            return null;
        }
    }

    public static function getList()
    {
        try {
            return Db::name('article')
                ->field("id,title,author,date,weight")
                ->order('weight', 'desc')
                ->select()
                ->toArray();
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * 发布文章的操作
     * @param string $title 文章的标题
     * @param string $author 文章作者
     * @param string $content 文章内容
     * @param int $weight 文章权重，默认值为普通权重（0）
     * @return bool 发布文章是否成功
     */
    public static function post(string $title, string $author, string $content, int $weight = 0)
    {
        $now = date("Y-m-d H:i:s");
        try {
            $count = Db::name('article')->insert([
                'title' => $title,
                'author' => $author,
                'weight' => $weight,
                'content' => $content,
                'date' => $now
            ]);
            if ($count == 1) {
                return true;
            } else {
                return false;
            }
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * @param int $articleId 文章ID
     * @param string $title 文章的新标题
     * @param string $author 文章的新作者名称
     * @param string $content 文章的内容
     * @param int $weight 文章的权重，默认值为 0
     * @return bool 返回是否操作成功（文章不存在也会返回操作成功，但不会更新数据）
     */
    public static function modify(int $articleId, string $title, string $author, string $content, int $weight = 0)
    {
        try {
            Db::name('article')
                ->where('id', $articleId)
                ->update([
                    'title' => $title,
                    'author' => $author,
                    'content' => $content,
                    'weight' => $weight
                ]);
            return true;
        } catch (DbException $e) {
            return false;
        }
    }

    public static function delete(int $articleId)
    {
        if (empty(self::findById($articleId))) {
            return false;
        }
        try {
            Db::name('article')->delete($articleId);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }
}