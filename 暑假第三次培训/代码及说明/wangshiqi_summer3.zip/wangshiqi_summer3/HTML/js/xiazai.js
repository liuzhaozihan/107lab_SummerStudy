$(document).ready(function(){
	$(".p1, .ul1").mouseenter(function(){
	   	$(".ul1").show("fast");
		$(".p1").css("background-color","#048EC1");
		});
	$(".p1").mouseleave(function(){
	   	$(".ul1").hide("fast");
		$(".p1").css("background-color","#084466");
		});
	$(".p2, .ul2").mouseenter(function(){
		$(".ul2").show("fast");
		$(".p2").css("background-color","#048EC1");
		});
	$(".p2").mouseleave(function(){
		$(".ul2").hide("fast");
		$(".p2").css("background-color","#084466");
		});
	$(".p3, .ul3").mouseenter(function(){
		$(".ul3").show("fast");
		$(".p3").css("background-color","#048EC1");
		});
	$(".p3").mouseleave(function(){
		$(".ul3").hide("fast");	
		$(".p3").css("background-color","#084466");
		});
	$(".p4, .ul4").mouseenter(function(){
		$(".ul4").show("fast");
		$(".p4").css("background-color","#048EC1");
		});
	$(".p4").mouseleave(function(){
		$(".ul4").hide("fast");	
		$(".p4").css("background-color","#084466");
		});
	$(".p5, .ul5").mouseenter(function(){
		$(".ul5").show("fast");
		$(".p5").css("background-color","#048EC1");
		});
	$(".p5").mouseleave(function(){
		$(".ul5").hide("fast");
		$(".p5").css("background-color","#084466");
        });
		$(".p0").mouseenter(function(){
			$(".p0").css("background-color","#048EC1");
			});
		$(".p0").mouseleave(function(){
			$(".p0").css("background-color","#084466");
		    });
		$(".p6, .ul6").mouseenter(function(){
			$(".ul6").show("fast");
			$(".p6").css("background-color","#048EC1");
			});
		$(".p6").mouseleave(function(){
			$(".ul6").hide("fast");
			$(".p6").css("background-color","#084466");
		    });		
		$(".p7, .ul7").mouseenter(function(){
			$(".ul7").show("fast");
			$(".p7").css("background-color","#048EC1");
			});
		$(".p7").mouseleave(function(){
			$(".ul7").hide("fast");
			$(".p7").css("background-color","#084466");
		    });		
		$(".p8, .ul8").mouseenter(function(){
			$(".ul8").show("fast");
			$(".p8").css("background-color","#048EC1");
			});
		$(".p8").mouseleave(function(){
			$(".ul8").hide("fast");
			$(".p8").css("background-color","#084466");
		    });
			//底部
		$(".foot2 a").mouseenter(function(){
			$(this).css("color","red");
			});	
		$(".foot2 a").mouseleave(function(){
			$(this).css("color","black");
			});	
			
		$(".l2, .l9, .l10, .l6, .l7, .l8").mouseenter(function(){
			
			$(this).css("background-color","#950101");
			});
		$(".l2, .l9, .l10, .l6, .l7, .l8").mouseleave(function(){
			
			$(this).css("background-color","#F4F4F4");
		    });		
		//轮播图
		var $l4 = $(".l4");
		var $pic = $(".pic");
					
					var PAGE_WIDTH = 300;//宽度
					var TIME = 400;//翻页的持续时间
					var ITEM_TIME = 20;//单元移动的间隔时间
					var imgCount = 3;
					
					function nextPage (next) {
						var currLeft = $pic.position().left;
						var offset = 0;
						offset = next ? -PAGE_WIDTH : PAGE_WIDTH;
						cssLeft = currLeft+offset;
						if(cssLeft=== -(imgCount+1) * PAGE_WIDTH){
							cssLeft =-PAGE_WIDTH;
						}else if(cssLeft=== 0){
							cssLeft = -imgCount * PAGE_WIDTH;
						}
						$pic.css("left",cssLeft);
					}
					var interval = setInterval(nextPage,2500);	
			
	 });